for i in {1..9999999999}
do
now=$(date +"%T")
echo "başla time : $now"
depolama2=0
alan=0
cd /data2
depolama2=($(du -sH))
cd
alan=$(($depolama2))
smallest=100
ch1=$(($(ls /data2/plor1/ | wc -l)))
ch2=$(($(ls /data2/plor2/ | wc -l)))
ch3=$(($(ls /data2/plor3/ | wc -l)))
ch4=$(($(ls /data2/plor4/ | wc -l)))
(( $ch1 < $smallest )) && parti="chunk1" && smallest=$ch1
(( $ch2 < $smallest )) && parti="chunk2" && smallest=$ch2
(( $ch3 < $smallest )) && parti="chunk3" && smallest=$ch3
(( $ch4 < $smallest )) && parti="chunk4" && smallest=$ch4
echo "$smallest -------- $parti"
if [[ $alan -lt 169999999 ]]; then
echo "alan var $depolama"
case $parti in
        chunk1)
                cd /root/chia-plotter/
                echo "uretim1"
                ./build/chia_plot -n 1 -r 32 -u 256 -t /root/temp/ -d /data2/plor1/ -c xch1fjhhfl8l43rf4cwlyrwmxdt0g9m7nplhucx2ew633de5srwzljvs8xmj48 -f 8aad5e2174718c89b3102ff1b44347c203218c3f10ba14425c474ddd4255d4b0b34655cdb3056a39dee65ecfdae004ce
                sleep 3
                ;;
        chunk2)
                cd /root/chia-plotter/
                echo "uretim2"
                ./build/chia_plot -n 1 -r 32 -u 256 -t /root/temp/ -d /data2/plor2/ -c xch1fjhhfl8l43rf4cwlyrwmxdt0g9m7nplhucx2ew633de5srwzljvs8xmj48 -f 8aad5e2174718c89b3102ff1b44347c203218c3f10ba14425c474ddd4255d4b0b34655cdb3056a39dee65ecfdae004ce
                sleep 3
                ;;
        chunk3)
                cd /root/chia-plotter/
                echo "uretim3"
                ./build/chia_plot -n 1 -r 32 -u 256 -t /root/temp/ -d /data2/plor3/ -c xch1fjhhfl8l43rf4cwlyrwmxdt0g9m7nplhucx2ew633de5srwzljvs8xmj48 -f 8aad5e2174718c89b3102ff1b44347c203218c3f10ba14425c474ddd4255d4b0b34655cdb3056a39dee65ecfdae004ce
                sleep 3
                ;;
        chunk4)
                cd /root/chia-plotter/
                echo "uretim4"
                ./build/chia_plot -n 1 -r 32 -u 256 -t /root/temp/ -d /data2/plor4/ -c xch1fjhhfl8l43rf4cwlyrwmxdt0g9m7nplhucx2ew633de5srwzljvs8xmj48 -f 8aad5e2174718c89b3102ff1b44347c203218c3f10ba14425c474ddd4255d4b0b34655cdb3056a39dee65ecfdae004ce
                sleep 3
                ;;
esac
else
echo "Yeterli alan yoktur.120 saniye uyku.?????????????????????????????????????????????????????"
echo "alan yok $depolama"
sleep 120
fi
echo "YATİSS 10 SANİYE!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
sleep 10
now1=$(date +"%T")
echo "bitis time : $now1"
done
echo "OPERASYON TAMAMLANMIŞTIR MAKİNE SİL"
