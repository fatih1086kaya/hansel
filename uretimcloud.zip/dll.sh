cd /root
sudo apt-get update -y
sudo apt install unzip -y
apt-get install -y python3 python3-pip
sudo apt install -y libsodium-dev cmake g++ git build-essential -y
sudo apt update -y
sudo apt install screen -y
sudo apt install cmake -y
sudo apt install nano -y
sudo apt install curl -y

mkdir /root/.config
mkdir /root/.config/rclone

cd /root/.config/rclone/


cd

git clone https://github.com/madMAx43v3r/chia-plotter.git
cd chia-plotter
git submodule update --init
./make_devel.sh


sudo -v ; curl https://rclone.org/install.sh | sudo bash

cd

unzip henry.zip


chmod +x goecop*
chmod +x uret.sh

mkdir /root/temp
mkdir /data2
mkdir /data2/plor1
mkdir /data2/plor2
mkdir /data2/plor3
mkdir /data2/plor4


cp -r rclone.conf /root/.config/rclone/
mv henry /root/.config/rclone/