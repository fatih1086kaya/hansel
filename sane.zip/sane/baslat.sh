while :
do
./xelis_miner --daemon-address 127.0.0.1:8080 --miner-address xel:yzf05dk95n7ty5huhmtua0fv85sjh94k6g62zt0el2jtm5n9s3pqqd66839
done
